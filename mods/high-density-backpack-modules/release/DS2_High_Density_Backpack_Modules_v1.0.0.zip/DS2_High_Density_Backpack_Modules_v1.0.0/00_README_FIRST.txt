DS2 High-Density Backpack Modules v1.0.0

1. Extract the complete ZIP.
2. Install a compatible external 64-bit ASI loader if needed.
3. Run INSTALL.cmd, or manually copy the ASI beside DS2.exe.
4. Start the game and verify that DS2_HighDensityBackpackModules.log contains status=PATCH_APPLIED.

Important: Before uninstalling, reduce the backpack to a layout that fits the original component footprints and save again.
