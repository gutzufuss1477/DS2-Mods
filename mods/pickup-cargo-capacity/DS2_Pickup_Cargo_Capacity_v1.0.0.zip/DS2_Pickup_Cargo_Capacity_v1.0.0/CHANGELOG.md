# Changelog

## v1.0.0

- First validated release.
- Increases the Off-road Pickup's real cargo capacity through four coordinated pack-area patches.
- Adds INI configuration from 160 to 480 size units.
- Uses 320 size units as the validated default.
- Verifies exact original instruction bytes before patching.
- Writes a status file with the effective configuration and patch state.
- Validated loading, unloading, driving, saving and reloading with approximately 320 units and more than 1800 kg.
