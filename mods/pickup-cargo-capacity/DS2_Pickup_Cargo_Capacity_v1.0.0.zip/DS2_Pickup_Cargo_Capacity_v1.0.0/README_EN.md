# DS2 Pickup Cargo Capacity v1.0.0

Increases the actual cargo capacity of the Off-road Pickup in Death Stranding 2.

## Installation

1. Fully close Death Stranding 2.
2. Replace any older `PickupCargoCapacity.asi` and `PickupCargoCapacity.ini` files.
3. Copy `PickupCargoCapacity.asi` and `PickupCargoCapacity.ini` into the folder used by your other ASI mods.
4. Start the game.
5. Optionally check `PickupCargoCapacity_STATUS.txt`. A successful activation reports `STATE=READY`.

A working ASI loader is required.

## Configuration

```ini
[PickupCargoCapacity]
Enabled=1
CapacityUnits=320
```

- Original capacity: `160`
- Supported range: `160` to `480`
- Values are rounded down to the nearest multiple of 16.
- `320` is the fully validated default configuration.

## Known cosmetic limitation

The percentage display still uses the original 160-unit reference. With `CapacityUnits=320`, a fully loaded pickup therefore shows approximately `200%`. Actual capacity, cargo, weight, saving/loading and driving remain functional.

## Validated test coverage

The `320` configuration was successfully tested with:

- loading to approximately 320 size units
- more than 1800 kg total cargo weight
- unloading and reloading cargo
- driving the overloaded pickup
- saving, fully restarting the game and loading the save again

## Uninstallation

Before uninstalling, reduce the pickup load to no more than 160 size units where possible. Then remove `PickupCargoCapacity.asi`, `PickupCargoCapacity.ini` and optionally `PickupCargoCapacity_STATUS.txt`.

## Compatibility and safety

Before modifying code, the mod validates the exact original bytes at all four patch sites. On an unsupported game version, it changes nothing and reports `STATE=ERROR` in `PickupCargoCapacity_STATUS.txt`.
