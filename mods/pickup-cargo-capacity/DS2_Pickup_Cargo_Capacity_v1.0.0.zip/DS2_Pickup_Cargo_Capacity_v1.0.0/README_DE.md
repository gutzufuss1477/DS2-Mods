# DS2 Pickup Cargo Capacity v1.0.0

Erhöht die reale Frachtkapazität des Pick-up-Geländewagens in Death Stranding 2.

## Installation

1. Death Stranding 2 vollständig beenden.
2. Alte `PickupCargoCapacity.asi`- und `PickupCargoCapacity.ini`-Dateien ersetzen.
3. `PickupCargoCapacity.asi` und `PickupCargoCapacity.ini` in denselben Ordner wie die übrigen ASI-Mods kopieren.
4. Spiel starten.
5. Optional `PickupCargoCapacity_STATUS.txt` kontrollieren. Bei erfolgreicher Aktivierung steht dort `STATE=READY`.

Ein funktionierender ASI-Loader wird vorausgesetzt.

## Konfiguration

```ini
[PickupCargoCapacity]
Enabled=1
CapacityUnits=320
```

- Originalwert: `160`
- Unterstützter Bereich: `160` bis `480`
- Werte werden auf das nächste tiefere Vielfache von 16 abgerundet.
- `320` ist die vollständig validierte Standardkonfiguration.

## Bekannte kosmetische Abweichung

Die Prozentanzeige verwendet weiterhin die originale Referenz von 160 Einheiten. Mit `CapacityUnits=320` zeigt ein vollständig beladener Pickup deshalb ungefähr `200 %`. Die reale Kapazität, Container, Gewichte, Speichern/Laden und das Fahrverhalten funktionieren trotzdem korrekt.

## Validierter Testumfang

Die Konfiguration `320` wurde erfolgreich geprüft mit:

- Beladung bis ungefähr 320 Grösseneinheiten
- mehr als 1800 kg Gesamtgewicht
- Entladen und erneutes Aufladen
- Fahren mit überladenem Pickup
- Speichern, vollständigem Spielneustart und erneutem Laden

## Deinstallation

Den Pickup vor der Deinstallation möglichst auf höchstens 160 Grösseneinheiten entladen. Danach `PickupCargoCapacity.asi`, `PickupCargoCapacity.ini` und optional `PickupCargoCapacity_STATUS.txt` entfernen.

## Kompatibilität und Sicherheit

Der Mod prüft vor jeder Änderung die exakten Originalbytes aller vier Codepositionen. Bei einer nicht unterstützten Spielversion wird nichts verändert und `PickupCargoCapacity_STATUS.txt` meldet `STATE=ERROR`.
