DS2 Remote Orders Overlay - No-Log Build

This build is based on the exact clean-log ASI already confirmed working in-game.

Change:
- The remaining normal log output is redirected to the Windows NUL device.
- No DS2 Remote Orders log file should be created.

Unchanged:
- executable machine code
- DS2 addresses and offsets
- overlay layout
- mission filtering
- imports and exports
- startup and worker logic

Installation:
1. Close the game.
2. Remove every other Remote Orders ASI.
3. Copy DS2_Remote_Orders_Overlay.asi next to DS2.exe.
4. Existing old log files can be deleted manually.
